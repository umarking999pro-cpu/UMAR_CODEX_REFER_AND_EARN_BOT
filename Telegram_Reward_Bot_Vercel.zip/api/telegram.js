const TelegramBot = require('node-telegram-bot-api');
const firebase = require('firebase/compat/app');
require('firebase/compat/firestore');

const firebaseConfig = { apiKey: process.env.FIREBASE_API_KEY || '', authDomain: process.env.FIREBASE_AUTH_DOMAIN || '', projectId: process.env.FIREBASE_PROJECT_ID || '', storageBucket: process.env.FIREBASE_STORAGE_BUCKET || '', messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || '', appId: process.env.FIREBASE_APP_ID || '' };
if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBAPP_URL = process.env.WEBAPP_URL || '';
const bot = new TelegramBot(BOT_TOKEN, { polling: false });

async function createOrEnsureUser(userId, firstName, photoURL, referralId) {
  const ref = db.doc(`users/${userId}`);
  const snap = await ref.get();
  if (!snap.exists) {
    await ref.set({ id: String(userId), name: firstName || 'User', photoURL: photoURL || '', coins: 0, reffer: 0, refferBy: referralId && String(referralId) !== String(userId) ? String(referralId) : null, tasksCompleted: 0, totalWithdrawals: 0, frontendOpened: true, rewardGiven: false });
  } else {
    await ref.set({ name: firstName || snap.data().name || 'User', photoURL: photoURL || snap.data().photoURL || '', frontendOpened: true }, { merge: true });
  }
}

async function processReferralReward(userId) {
  const userRef = db.doc(`users/${userId}`);
  const ledgerRef = db.doc(`ref_rewards/${userId}`);
  await db.runTransaction(async tx => {
    const [u, ledger] = await Promise.all([tx.get(userRef), tx.get(ledgerRef)]);
    if (!u.exists || ledger.exists) return;
    const d = u.data();
    if (d.frontendOpened !== true || d.rewardGiven === true || !d.refferBy) return;
    const referrerRef = db.doc(`users/${d.refferBy}`);
    const referrer = await tx.get(referrerRef);
    if (!referrer.exists || String(d.refferBy) === String(userId)) return;
    tx.update(referrerRef, { coins: firebase.firestore.FieldValue.increment(500), reffer: firebase.firestore.FieldValue.increment(1) });
    tx.update(userRef, { rewardGiven: true });
    tx.set(ledgerRef, { userId: String(userId), referrerId: String(d.refferBy), reward: 500, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  });
}
async function updateField(userId, field, value) { return db.doc(`users/${userId}`).update({ [field]: value }); }
async function incrementField(userId, field, amount) { return db.doc(`users/${userId}`).update({ [field]: firebase.firestore.FieldValue.increment(amount) }); }

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(200).json({ ok: true, message: 'Telegram webhook endpoint' });
  try {
    const update = req.body || {};
    if (update.message && update.message.from) {
      const m = update.message, u = m.from;
      if (m.text && m.text.startsWith('/start')) {
        const parts = m.text.trim().split(/\s+/);
        const referralId = parts[1] || null;
        await createOrEnsureUser(u.id, u.first_name, u.photo_url || '', referralId);
        await processReferralReward(u.id);
        const buttons = [];
        if (WEBAPP_URL) buttons.push([{ text: '▶ Open App', web_app: { url: WEBAPP_URL } }]);
        buttons.push([{ text: '📢 Channel', url: 'https://t.me/finisher_tech' }, { text: '🌐 Community', url: 'https://t.me/finisher_techg' }]);
        await bot.sendMessage(m.chat.id, `👋 Hi! Welcome ${u.first_name || ''} ⭐\nYaha aap tasks complete karke real rewards kama sakte ho!\n\n🔥 Daily Tasks\n🔥 Video Watch\n🔥 Mini Apps\n🔥 Referral Bonus\n🔥 Auto Wallet System\n\nReady to earn?\nTap START and your journey begins!`, { reply_markup: { inline_keyboard: buttons } });
      }
    }
    return res.status(200).json({ ok: true });
  } catch (e) { console.error(e); return res.status(500).json({ ok: false, error: 'Webhook processing failed' }); }
};
